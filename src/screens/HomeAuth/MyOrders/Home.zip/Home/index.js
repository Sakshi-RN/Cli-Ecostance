import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Platform,
    FlatList,
    TouchableOpacity
} from 'react-native';
import { connect } from 'react-redux';
import ImageWrapper from '../../../components/image';
import imagePaths from '../../../utilities/imagePaths';
import HomeCard from '../../../components/homeCard';
import Header from '../../../components/header';
import styles from './style';
import { HeartIcon, ShoppingCartIcon, PlusWhiteIcon } from '../../../assets';
import { Colors } from '../../../theme/colors';
import { fetchProducts } from '../../../redux/features/getProductsReducer/Index';

const Home = ({ products, loading, error, fetchProducts, navigation }) => {
    const [showToggle, setShowToggle] = useState(false);

    // console.log("productsproductsproducts",products)

    useEffect(() => {
        fetchProducts();
    }, [fetchProducts]);

    const onRefresh = () => {
        fetchProducts();
    };

    return (
        <>
            <View style={styles.topBanner}>
                <ImageWrapper
                    imagePath={imagePaths.loginTopVector}
                    maxWidth={"100%"} maxHeight={Platform.OS === "ios" ? 89 : 80}
                />
                <View style={styles.headerRowAdjust}>
                    <Header
                        navigation={navigation}
                        centerLogo={true}
                        rightIcon={
                            <View style={styles.shoppingCartRow}>
                                <TouchableOpacity style={styles.shoppingCartButton}
                                    onPress={() => navigation.navigate("Cart")}
                                >
                                    <ShoppingCartIcon />
                                </TouchableOpacity>
                                <TouchableOpacity>
                                    <HeartIcon />
                                </TouchableOpacity>
                            </View>
                        }
                        backIcon={false}
                    />
                </View>
            </View>

            <View style={styles.container}>
                <View style={styles.loginContainer}>
                    {loading ? (
                        <Text>Loading...</Text>
                    ) : error ? (
                        <Text>Error: {error}</Text>
                    ) : (
                        <FlatList
                            showsVerticalScrollIndicator={true}
                            contentContainerStyle={{ flexDirection: 'column' }}
                            data={products}
                            keyExtractor={(item, index) => String(index)}
                            onRefresh={onRefresh}
                            refreshing={loading}
                            renderItem={({ item }) => (
                                <HomeCard
                                    dataItem={item}
                                    navigation={navigation}
                                />
                            )}
                        />
                    )}
                </View>
            </View>

            {!showToggle ? (
                <View style={[styles.bottomButtonAdjust, { bottom: showToggle ? 100 : 30 }]}>
                    <View style={styles.bottomRow}>
                        <TouchableOpacity style={styles.plusIconWrapper}
                            onPress={() => setShowToggle(true)}
                        >
                            <PlusWhiteIcon />
                        </TouchableOpacity>
                    </View>
                </View>
            ) : (
                <View style={[styles.bottomRowAdjust, {
                    backgroundColor: showToggle ? Colors.OFFBLACK : "transparent",
                    opacity: showToggle ? 0.9 : 0.9,
                }]}>
                    <View style={[styles.bottomButtonAdjust, { bottom: showToggle ? 100 : 30 }]}>
                        <View style={styles.bottomRow}>
                            {showToggle && (
                                <TouchableOpacity style={styles.percentIconButton}>
                                    <ImageWrapper
                                        imagePath={imagePaths.percentBlackIcon}
                                        maxWidth={24} maxHeight={24}
                                    />
                                </TouchableOpacity>
                            )}
                            {showToggle && (
                                <TouchableOpacity style={styles.percentIconButton}>
                                    <ImageWrapper
                                        imagePath={imagePaths.downArrowIcon}
                                        maxWidth={25} maxHeight={28}
                                    />
                                </TouchableOpacity>
                            )}
                            {showToggle && (
                                <TouchableOpacity style={styles.percentIconButton}
                                    onPress={() => navigation.navigate("Cart")}
                                >
                                    <ImageWrapper
                                        imagePath={imagePaths.cartBucketIcon}
                                        maxWidth={35} maxHeight={35}
                                    />
                                </TouchableOpacity>
                            )}
                            {showToggle && (
                                <TouchableOpacity style={styles.crossIconButton}
                                    onPress={() => setShowToggle(false)}
                                >
                                    <ImageWrapper
                                        imagePath={imagePaths.crossIcon}
                                        maxWidth={20} maxHeight={20}
                                    />
                                </TouchableOpacity>
                            )}
                        </View>
                    </View>
                </View>
            )}
        </>
    );
};

const mapStateToProps = state => ({
    products: state?.product?.products,
    loading: state?.product?.loading,
    error: state?.product?.error,
});

const mapDispatchToProps = {
    fetchProducts,
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
